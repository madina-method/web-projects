<?php 
	include 'connect.php';

	$id = $_GET['id'];
	$checked = $_GET['checked'];

	if($checked == 0) $checked = 1;
	else $checked = 0;
	print($checked);
	$sql = "UPDATE tasks SET done =  ".$checked . " WHERE id=".$id;
	print($sql);
	mysqli_query($conn, $sql) or die(mysqli_error($conn));
	header('Location: index.php');

 ?>