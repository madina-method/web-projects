<?php
	$database = "todo";
	$servername = "localhost";
	$username = "root";
	$password = "";

	// Create connection
	$conn = mysqli_connect($servername, $username, $password);

	// Check connection
	if (!$conn) {
		die("Connection failed: " . $conn->connect_error);
	} 

	$db_selected = mysqli_select_db($conn, $database);
?>