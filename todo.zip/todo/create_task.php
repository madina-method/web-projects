<?php
include 'connect.php';

if (isset($_POST['place'])){

	$sql = "INSERT INTO tasks (name, done) VALUES ('" . $_POST['place'] ."', 0)";

	$result = mysqli_query($conn,$sql);

	if ($result) {
		header('Location: index.php');	   
		echo "New record created successfully";
	} else {
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
}
?>