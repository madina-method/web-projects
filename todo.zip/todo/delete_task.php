<?php
include 'connect.php';

if (isset($_GET['id'])) {
	$sql = "DELETE FROM tasks WHERE ID = " . $_GET['id'];

	if (mysqli_query($conn, $sql)) {
		header('Location: index.php');	   
		echo "Record updated successfully";

	} else {
		echo "Error: " . $sql . "<br>" . mysqli_error($conn);
	}
}
?>