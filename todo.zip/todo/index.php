<html>
<head>
	<title>To Do</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
	<body>
		<?php
			include 'connect.php';

			$result = mysqli_query($conn, "SELECT * from tasks ORDER BY done ASC, id DESC");

			if (!$result) {
				$message  = 'Неверный запрос: ' . mysqli_error($conn) . "\n";
				die($message);
			}
		?>


		<div id="myDIV" class="header">
			<h2>My To Do List</h2>
			<form  method="post" action="create_task.php">
				<input type="text" id="myInput" placeholder="Title..." name="place">
				<input type='submit' class="addBtn" value="Add">
			</form>
		</div>

		<ul id="myUL">
			<?php

				while($row = mysqli_fetch_array($result)){
					$class_name = "";
					if ($row[2]) $class_name = 'checked';
					echo
					"<li class='$class_name'>" . 
							"<a href='edit_task.php?id=$row[0]&checked=$row[2]'>".$row[1] ."</a>".
						"<a href='delete_task.php?id=$row[0]'>" .
							"<span class='close'/>x</span>" .
						"</a>".
					"</li>" ;
				}
			?>

		</ul>
	</body>
</html>