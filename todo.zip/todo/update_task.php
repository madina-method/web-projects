<?php
	include 'connect.php';

	if (isset($_GET['id'])) {
		if ($_GET['status'] == 1) $new_status = 0;
		else $new_status = 1;
		$sql = "UPDATE tasks SET done = " . $new_status . "  WHERE ID = " . $_GET['id'];

		if (mysqli_query($conn, $sql)) {
			header('Location: index.php');	   
			echo "Record updated successfully";
		} else {
			echo "Error: " . $sql . "<br>" . mysqli_error($conn);
		}
	}
?>